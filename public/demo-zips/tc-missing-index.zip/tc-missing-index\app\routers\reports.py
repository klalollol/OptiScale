from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.queries.order_queries import get_pending_orders

router = APIRouter(prefix="/api/reports", tags=["reports"])

@router.get("/summary")
def daily_summary(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
):
    orders = get_pending_orders(db, since_days=days)
    total = sum(float(o.total_amount) for o in orders)
    return {"period_days": days, "pending_count": len(orders), "pending_total": total}
