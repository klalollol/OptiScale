from sqlalchemy import Column, Integer, String, DateTime, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

# =============================================================================
# MISSING INDEX WARNING
# =============================================================================
# Columns `status` and `created_at` are frequently used in WHERE clauses
# and ORDER BY but have NO index defined.
# On a table with 1,000,000+ rows this causes a sequential scan (~840 MB buffer)
# on every /api/orders/pending and /api/reports/summary request.
#
# OptiScale recommendation:
#   Index("ix_orders_status_created", "status", "created_at")
# =============================================================================
class Order(Base):
    __tablename__ = "orders"
    id          = Column(Integer, primary_key=True, index=True)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=False)
    status      = Column(String(20), nullable=False)      # NO INDEX — full scan
    total_amount= Column(Numeric(12, 2), nullable=False)
    created_at  = Column(DateTime, default=datetime.datetime.utcnow)  # NO INDEX
    updated_at  = Column(DateTime, onupdate=datetime.datetime.utcnow)
    # relationships
    customer    = relationship("Customer", back_populates="orders")
    items       = relationship("OrderItem", back_populates="order")
