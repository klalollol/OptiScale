from sqlalchemy.orm import Session
from sqlalchemy import text
from app.models.order import Order
from app.models.order_item import OrderItem
import datetime

# =============================================================================
# BOTTLENECK: FULL TABLE SCAN — NO INDEX ON status OR created_at
# =============================================================================
# At 1,000,000 rows in `orders`, PostgreSQL cannot use an index scan.
# EXPLAIN ANALYZE output (unoptimized):
#   Seq Scan on orders  (cost=0.00..48920.00 rows=12400 width=72)
#   Filter: ((status = 'pending') AND (created_at > '...'))
#   Rows Removed by Filter: 987600
#   Buffers: shared hit=840000
#
# This causes 1,890 ms average query time on a loaded DB instance.
# =============================================================================
def get_pending_orders(db: Session, since_days: int = 7):
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(days=since_days)

    # Sequential scan — no index on `status` or `created_at`
    orders = db.query(Order).filter(
        Order.status == "pending",
        Order.created_at >= cutoff,
    ).order_by(Order.created_at.desc()).all()

    return orders


def get_order_summary(db: Session, customer_id: int):
    # Sequential scan on order_items (no index on order_id)
    raw = db.execute(text("""
        SELECT o.id, o.status, o.total_amount, o.created_at,
               COUNT(oi.id) AS item_count
        FROM orders o
        LEFT JOIN order_items oi ON oi.order_id = o.id
        WHERE o.customer_id = :cid
        GROUP BY o.id
        ORDER BY o.created_at DESC
        LIMIT 50
    """), {"cid": customer_id})
    return [dict(row._mapping) for row in raw]

# -----------------------------------------------------------------------------
# OPTIMIZED VERSION (applied by OptiScale):
# -----------------------------------------------------------------------------
# Migration to add:
#   op.create_index("ix_orders_status_created_at", "orders", ["status", "created_at"])
#   op.create_index("ix_order_items_order_id", "order_items", ["order_id"])
#
# After adding indexes:
#   Index Scan using ix_orders_status_created_at on orders
#   (cost=0.56..312.44 rows=12400 width=72)
#   Query time: ~120 ms  (was 1,890 ms)
# -----------------------------------------------------------------------------
