from fastapi import FastAPI
from app.routers import orders, reports

app = FastAPI(title="Order Management API", version="2.1.0")
app.include_router(orders.router)
app.include_router(reports.router)
