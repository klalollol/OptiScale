from sqlalchemy import Column, Integer, String, Numeric, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base

# order_id is a foreign key used in every join — but has NO index.
# This forces a sequential scan of order_items on every JOIN.
class OrderItem(Base):
    __tablename__ = "order_items"
    id         = Column(Integer, primary_key=True, index=True)
    order_id   = Column(Integer, ForeignKey("orders.id"), nullable=False)  # NO INDEX
    product_id = Column(Integer, nullable=False)
    name       = Column(String(200), nullable=False)
    quantity   = Column(Integer, nullable=False)
    unit_price = Column(Numeric(10, 2), nullable=False)
    # relationship
    order      = relationship("Order", back_populates="items")
