from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.queries.order_queries import get_pending_orders, get_order_summary

router = APIRouter(prefix="/api/orders", tags=["orders"])

@router.get("/pending")
def pending_orders(
    since_days: int = Query(7, ge=1, le=90),
    db: Session = Depends(get_db),
):
    """
    Returns pending orders from the last N days.
    WARNING: full table scan — no index on orders.status or orders.created_at
    """
    return get_pending_orders(db, since_days=since_days)

@router.get("/{customer_id}/summary")
def order_summary(customer_id: int, db: Session = Depends(get_db)):
    """
    Returns order summary for a customer.
    WARNING: sequential scan on order_items — no index on order_id
    """
    return get_order_summary(db, customer_id=customer_id)
