# tc-missing-index

**Bottleneck**: Missing database indexes — full table scans on large tables
**Severity**: MODERATE
**Stack**: Python 3.11 · FastAPI · PostgreSQL · SQLAlchemy

## What OptiScale should find

The `/api/orders/pending` and `/api/reports/summary` endpoints query large tables
with no index on the filter columns:

- `orders.status` — unindexed, full scan on every status filter
- `orders.created_at` — unindexed, no range-scan optimisation
- `order_items.order_id` — unindexed foreign key, causes seq scan on joins

At 1M rows in `orders`, each request does a sequential scan of the entire table.

## Expected optimization result

| Metric | Before | After |
|--------|--------|-------|
| Latency (p95) | 2,140 ms | 470 ms |
| Throughput | 28 req/s | 127 req/s |
| DB query time | 1,890 ms | 120 ms |
| Memory (DB buf) | 840 MB | 290 MB |

OptiScale fix: add composite index `(status, created_at)` on `orders` and index `(order_id)` on `order_items`.
