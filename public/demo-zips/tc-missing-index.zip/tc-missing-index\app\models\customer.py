from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

class Customer(Base):
    __tablename__ = "customers"
    id         = Column(Integer, primary_key=True, index=True)
    email      = Column(String(200), unique=True, nullable=False, index=True)
    name       = Column(String(120), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    orders     = relationship("Order", back_populates="customer")
