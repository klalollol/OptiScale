from sqlalchemy import Column, Integer, String, Numeric, Boolean, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base

class Product(Base):
    __tablename__ = "products"
    id          = Column(Integer, primary_key=True, index=True)
    category_id = Column(Integer, ForeignKey("categories.id"), nullable=False, index=True)
    sku         = Column(String(50), unique=True, nullable=False, index=True)
    name        = Column(String(200), nullable=False)
    description = Column(String(2000), nullable=True)
    active      = Column(Boolean, default=True, nullable=False)
    # relationships
    category    = relationship("Category", back_populates="products", lazy="select")
    price_tiers = relationship("PriceTier", back_populates="product", lazy="selectin")

    # Composite index for the most common query pattern
    __table_args__ = (
        Index("ix_products_category_active", "category_id", "active"),
    )
