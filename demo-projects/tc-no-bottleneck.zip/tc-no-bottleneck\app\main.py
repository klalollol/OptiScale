from fastapi import FastAPI
from app.routers import products, categories

app = FastAPI(
    title="Product Catalogue API",
    version="3.0.0",
    description="Optimized product catalogue — no performance bottlenecks.",
)
app.include_router(products.router)
app.include_router(categories.router)
