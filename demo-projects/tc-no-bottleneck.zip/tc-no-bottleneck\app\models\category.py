from sqlalchemy import Column, Integer, String, Boolean
from sqlalchemy.orm import relationship
from app.database import Base

class Category(Base):
    __tablename__ = "categories"
    id       = Column(Integer, primary_key=True, index=True)
    slug     = Column(String(80), unique=True, nullable=False, index=True)
    name     = Column(String(120), nullable=False)
    active   = Column(Boolean, default=True)
    products = relationship("Product", back_populates="category", lazy="dynamic")
