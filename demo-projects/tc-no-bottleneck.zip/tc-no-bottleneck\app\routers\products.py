from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.queries.product_queries import get_products_by_category, get_product_by_sku

router = APIRouter(prefix="/api/products", tags=["products"])

@router.get("/")
def list_products(
    category: str = Query(..., description="Category slug"),
    page: int     = Query(1, ge=1),
    page_size: int= Query(40, ge=1, le=100),
    db: Session   = Depends(get_db),
):
    """
    Paginated product listing with batch-loaded relationships.
    No N+1 queries. Indexed filter columns.
    """
    products = get_products_by_category(db, category_slug=category, page=page, page_size=page_size)
    if not products and page == 1:
        raise HTTPException(status_code=404, detail="Category not found or empty")
    return products

@router.get("/{sku}")
def get_product(sku: str, db: Session = Depends(get_db)):
    product = get_product_by_sku(db, sku=sku)
    if not product:
        raise HTTPException(status_code=404, detail="Product not found")
    return product
