from sqlalchemy import Column, Integer, String, Numeric, ForeignKey, Index
from sqlalchemy.orm import relationship
from app.database import Base

class PriceTier(Base):
    __tablename__ = "price_tiers"
    id         = Column(Integer, primary_key=True, index=True)
    product_id = Column(Integer, ForeignKey("products.id"), nullable=False)
    tier_name  = Column(String(40), nullable=False)
    price      = Column(Numeric(10, 2), nullable=False)
    product    = relationship("Product", back_populates="price_tiers")

    __table_args__ = (
        Index("ix_price_tiers_product_id", "product_id"),
    )
