from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.category import Category

router = APIRouter(prefix="/api/categories", tags=["categories"])

@router.get("/")
def list_categories(db: Session = Depends(get_db)):
    """Active categories — small table, single indexed query."""
    return db.query(Category).filter(Category.active == True).order_by(Category.name).all()
