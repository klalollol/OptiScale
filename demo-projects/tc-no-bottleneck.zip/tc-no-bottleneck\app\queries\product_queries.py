from sqlalchemy.orm import Session, joinedload, selectinload
from app.models.product import Product
from app.models.category import Category

# =============================================================================
# OPTIMIZED: batch-loaded relationships, no N+1
# =============================================================================
# Uses selectinload for price_tiers (1 extra query total, not N queries).
# Uses joinedload for category (single JOIN, not N separate SELECTs).
# Pagination prevents unbounded result sets.
# All filter columns are indexed.
# =============================================================================

def get_products_by_category(
    db: Session,
    category_slug: str,
    page: int = 1,
    page_size: int = 40,
) -> list[Product]:
    """
    Returns paginated products for a category.
    Query count: 2 (1 for products+category JOIN, 1 for price_tiers batch load).
    """
    offset = (page - 1) * page_size
    return (
        db.query(Product)
        .join(Product.category)
        .filter(
            Category.slug == category_slug,
            Product.active == True,
        )
        .options(
            joinedload(Product.category),       # JOIN — not a separate query
            selectinload(Product.price_tiers),  # 1 batch query for all tiers
        )
        .order_by(Product.id)
        .offset(offset)
        .limit(page_size)
        .all()
    )


def get_product_by_sku(db: Session, sku: str) -> Product | None:
    """
    Single product lookup by indexed SKU column.
    Query count: 1 (index scan on sku).
    """
    return (
        db.query(Product)
        .filter(Product.sku == sku)
        .options(
            joinedload(Product.category),
            selectinload(Product.price_tiers),
        )
        .first()
    )
