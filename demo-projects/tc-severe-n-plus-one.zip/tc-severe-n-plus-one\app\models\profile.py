from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

class UserProfile(Base):
    __tablename__ = "user_profiles"
    id           = Column(Integer, primary_key=True, index=True)
    username     = Column(String(80), unique=True, nullable=False)
    display_name = Column(String(120), nullable=False)
    avatar_url   = Column(String(300), nullable=True)
    bio          = Column(String(500), nullable=True)
    created_at   = Column(DateTime, default=datetime.datetime.utcnow)
    # relationships
    posts        = relationship("Post", back_populates="author")
    comments     = relationship("Comment", back_populates="author")
