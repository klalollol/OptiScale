from sqlalchemy.orm import Session
from app.models.post import Post
from app.models.comment import Comment
from app.models.profile import UserProfile

# =============================================================================
# BOTTLENECK: 3-LEVEL NESTED N+1 QUERY PATTERN
# =============================================================================
# This function is called on every /api/feed/timeline request.
#
# Query count breakdown for a timeline with 50 posts, avg 20 comments/post:
#   1   query  — fetch all posts
#   50  queries — fetch comments for each post           (N)
#   1,000 queries — fetch author profile for each comment (N x M)
#   ─────────────────
#   1,051 SQL round-trips for ONE API call
#
# At 100 concurrent users this saturates the connection pool immediately.
# =============================================================================
def get_timeline(db: Session, user_id: int, limit: int = 50):
    # Level 1: fetch posts — 1 query
    posts = db.query(Post).filter(
        Post.author_id == user_id
    ).order_by(Post.created_at.desc()).limit(limit).all()

    for post in posts:
        # Level 2: fetch comments per post — N queries
        post.comments = db.query(Comment).filter(
            Comment.post_id == post.id
        ).order_by(Comment.created_at).all()

        for comment in post.comments:
            # Level 3: fetch comment author profile — N×M queries
            comment.author = db.query(UserProfile).filter(
                UserProfile.id == comment.author_id
            ).first()

    return posts

# -----------------------------------------------------------------------------
# OPTIMIZED VERSION (applied by OptiScale):
# -----------------------------------------------------------------------------
# from sqlalchemy.orm import joinedload, subqueryload
#
# def get_timeline(db: Session, user_id: int, limit: int = 50):
#     return (
#         db.query(Post)
#         .filter(Post.author_id == user_id)
#         .order_by(Post.created_at.desc())
#         .limit(limit)
#         .options(
#             subqueryload(Post.comments).joinedload(Comment.author),
#             joinedload(Post.author),
#         )
#         .all()
#     )
# Result: 3 queries total (posts + batch comments + batch profiles)
# -----------------------------------------------------------------------------
