from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from app.database import Base
import datetime

class Post(Base):
    __tablename__ = "posts"
    id         = Column(Integer, primary_key=True, index=True)
    author_id  = Column(Integer, ForeignKey("user_profiles.id"), nullable=False)
    title      = Column(String(200), nullable=False)
    body       = Column(String(5000), nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    # relationships
    author     = relationship("UserProfile", back_populates="posts")
    comments   = relationship("Comment", back_populates="post")
