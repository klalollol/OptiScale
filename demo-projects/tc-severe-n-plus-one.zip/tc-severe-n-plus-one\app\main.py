from fastapi import FastAPI
from app.routers import feed, users

app = FastAPI(title="Social Feed API", version="1.0.0")
app.include_router(feed.router)
app.include_router(users.router)
