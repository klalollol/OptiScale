# tc-severe-n-plus-one

**Bottleneck**: Severely nested N+1 query pattern (3 levels deep)
**Severity**: CRITICAL
**Stack**: Python 3.11 · FastAPI · PostgreSQL · SQLAlchemy

## What OptiScale should find

The `/api/feed/timeline` endpoint triggers a 3-level nested N+1:
1. Load all posts for a user's timeline (1 query)
2. For each post, load all comments (N queries)
3. For each comment, load the author's profile (N×M queries)

With 50 posts × 20 comments = **1,001+ SQL queries per single API call**.

## Expected optimization result

| Metric | Before | After |
|--------|--------|-------|
| Latency (p95) | 4,820 ms | 387 ms |
| Throughput | 12 req/s | 148 req/s |
| DB queries/req | 1,001 | 3 |
| CPU usage | 94% | 21% |

OptiScale fix: replace nested loops with `joinedload` + `subqueryload` on the ORM relationships.
