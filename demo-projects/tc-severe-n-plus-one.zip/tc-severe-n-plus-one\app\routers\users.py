from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models.profile import UserProfile

router = APIRouter(prefix="/api/users", tags=["users"])

@router.get("/{user_id}")
def get_user(user_id: int, db: Session = Depends(get_db)):
    return db.query(UserProfile).filter(UserProfile.id == user_id).first()
