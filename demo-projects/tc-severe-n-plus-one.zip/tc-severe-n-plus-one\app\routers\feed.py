from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.queries.feed_queries import get_timeline

router = APIRouter(prefix="/api/feed", tags=["feed"])

@router.get("/timeline")
def timeline(
    user_id: int = Query(..., description="User ID to fetch timeline for"),
    limit: int  = Query(50, ge=1, le=200),
    db: Session = Depends(get_db),
):
    """
    Fetch the social timeline for a user.
    WARNING: triggers 3-level N+1 query pattern — 1,000+ SQL queries per call.
    """
    return get_timeline(db, user_id=user_id, limit=limit)
